====================================================================
  SAP ERP BLUEPRINT & ABAP ALV CUSTOM REPORT
  GlobalEdge Industries Pvt. Ltd. — Academic Project 2024-25
====================================================================

PROJECT OVERVIEW
--------------------------------------------------------------------
This project implements a complete greenfield SAP ERP setup for a
fictitious company "GlobalEdge Industries Pvt. Ltd." covering:

  FI  — Financial Accounting (company codes, GL, tax, banking)
  MM  — Materials Management (plants, purchasing, inventory)
  SD  — Sales & Distribution (sales org, pricing, order-to-cash)

Plus a real ABAP development:
  ZGEBI_VENDOR_STOCK_SO_RPT — Custom ALV Grid Report combining
  open PO data, current stock and linked open sales orders.

====================================================================
FOLDER STRUCTURE
====================================================================

SAP_Project/
│
├── ABAP/
│   ├── ZGEBI_VENDOR_STOCK_SO_RPT.abap     ← Main ABAP program
│   └── ZGEBI_ALV_STR_SE11_Definition.txt  ← SE11 structure guide
│
├── Config_Steps/
│   ├── FI_Customisation_Steps.txt         ← FI config steps
│   ├── MM_Customisation_Steps.txt         ← MM config steps
│   └── SD_Customisation_Steps.txt         ← SD config steps
│
├── Documentation/
│   └── SAP_Project_Report.pdf             ← 5-page project report
│
└── README.txt                             ← This file

====================================================================
ENTERPRISE STRUCTURE SUMMARY
====================================================================

  Client            : 800 (GlobalEdge Group)
  Company Code      : GE01 (India, INR) | GE02 (Europe, EUR)
  Controlling Area  : GE00
  Chart of Accounts : GEOA
  Fiscal Year       : V3 (April – March)
  Plant             : P001 Mumbai | P002 Pune
  Storage Locations : SL01 Raw Materials | SL02 Finished Goods
  Purch. Org.       : PO01 Central Purchasing
  Sales Org.        : SO01 India
  Dist. Channel     : DC01 Direct Sales
  Division          : DV01 Industrial Equipment

====================================================================
HOW TO SET UP THE ABAP REPORT IN SAP
====================================================================

PRE-REQUISITES:
  - Access to SAP ECC 6.0 or S/4HANA (IDES sandbox recommended)
  - Developer key activated for your user (transaction SLICENSE)
  - Authorization for SE38, SE11, SE93

STEP 1 — Create the DDIC Structure (SE11)
  1. Open SE11
  2. Select "Data type", enter: ZGEBI_ALV_STR
  3. Click Create → choose "Structure"
  4. Short description: ALV Output Structure - Vendor Stock SO Report
  5. Add components as documented in ZGEBI_ALV_STR_SE11_Definition.txt
  6. Save → Activate (Ctrl+F3)
  7. Assign to package $TMP (local, no transport) or your Z-package

STEP 2 — Create and Activate the ABAP Program (SE38)
  1. Open SE38
  2. Enter program name: ZGEBI_VENDOR_STOCK_SO_RPT
  3. Click Create
  4. Title      : Vendor / Stock / Open Sales Order ALV Report
  5. Type        : Executable Program
  6. Status      : Test program (or Production)
  7. Application : Cross-application
  8. Paste the entire content of ZGEBI_VENDOR_STOCK_SO_RPT.abap
  9. Save → Activate (Ctrl+F3)
 10. Fix any syntax errors (usually none if pasted correctly)

  NOTE: If the program has MESSAGE-ID ZGE_MESSAGES and you don't
  have that message class, either:
  - Remove the MESSAGE-ID from the REPORT statement, OR
  - Create message class ZGE_MESSAGES via SE91

STEP 3 — Create Custom Transaction Code (SE93)
  1. Open SE93
  2. Enter transaction code: ZGEBI01
  3. Click Create
  4. Short description: Vendor Stock Sales Order ALV Report
  5. Select "Program and selection screen (report transaction)"
  6. Program: ZGEBI_VENDOR_STOCK_SO_RPT
  7. Screen number: 1000 (leave blank for default)
  8. Save and activate

STEP 4 — Create Authorization Object (Optional, recommended)
  1. Open SU21
  2. Create auth object Z_GE_RPT under class ZGE
  3. Fields: BUKRS (Company Code), ACTVT (Activity)
  4. Assign to your user role via PFCG
  NOTE: If you skip this, comment out the AUTHORITY-CHECK
        section in the ABAP program (lines marked CHECK_AUTHORIZATION)

STEP 5 — Run the Report
  1. Open ZGEBI01 (or SE38 → ZGEBI_VENDOR_STOCK_SO_RPT → F8)
  2. Enter your company code (e.g., GE01 or your IDES code)
  3. Enter plant if needed
  4. Press F8 to execute
  5. ALV grid appears with columns as defined

====================================================================
ABAP PROGRAM FEATURES
====================================================================

  Selection Screen:
    - Company Code (mandatory, default GE01)
    - Plant (default P001)
    - Vendor number (optional)
    - Material number (optional)
    - PO creation date range (optional)
    - Max rows (default 1000)
    - Storage location for stock (default SL01)

  Output Columns:
    1.  Vendor Number     (key column)
    2.  Vendor Name
    3.  PO Number         (HOTSPOT — click opens ME23N)
    4.  Company Code
    5.  Plant
    6.  Material Number
    7.  Material Description
    8.  PO Quantity        (totals row active)
    9.  Unit of Measure
    10. Net Value          (totals row active)
    11. Currency
    12. Unrestricted Stock (totals row active)
    13. Sales Order        (HOTSPOT — click opens VA03)
    14. SO Item
    15. SO Quantity        (totals row active)
    16. Stock OK? checkbox (X if stock >= SO demand)

  Interactive Features:
    - Click PO Number   → opens ME23N (PO display) directly
    - Click Sales Order → opens VA03 (SO display) directly
    - Sort any column by clicking the column header
    - Filter using the funnel icon in ALV toolbar
    - Export to Excel via ALV toolbar spreadsheet icon
    - Save personal or global column layouts as variants
    - Grand Total row for all quantity/value columns

====================================================================
TESTING WITH IDES DATA
====================================================================

  If using SAP IDES system, adjust company code and plant
  to match your IDES data (common: 1000, 2000 for company codes).

  Minimum test data needed:
  1. At least one vendor (LFA1)
  2. At least one open PO with item (EKKO + EKPO where ELIKZ = ' ')
  3. Stock record in MARD for the PO material
  4. Optional: open sales order (VBAK/VBAP where GBSTA <> 'C')

  Quick check if data exists:
    SE16 → EKKO → enter company code → check if rows exist
    SE16 → EKPO → ELIKZ = ' ' (space) → open PO items

====================================================================
TRANSPORT REQUEST
====================================================================

  For moving to QA or Production:
  1. SE10 → Create Workbench request ZDEVK9XXXXX
  2. Include objects:
     - PROG ZGEBI_VENDOR_STOCK_SO_RPT (program)
     - TABD ZGEBI_ALV_STR              (structure)
     - TRAN ZGEBI01                    (transaction)
  3. STMS → release and import to target system

====================================================================
CONTACT & SUBMISSION
====================================================================

  Project  : SAP ERP Blueprint & ABAP ALV Custom Report
  Company  : GlobalEdge Industries Pvt. Ltd. (Fictitious)
  GitHub   : https://github.com/YOUR_USERNAME/SAP_Blueprint_Project
  Report   : See Documentation/SAP_Project_Report.pdf

====================================================================
