*&---------------------------------------------------------------------*
*& Report  : ZGEBI_VENDOR_STOCK_SO_RPT
*& Title   : Vendor + Stock + Open Sales Order ALV Grid Report
*& Company : GlobalEdge Industries Pvt. Ltd.
*& T-Code  : ZGEBI01  (register via SE93)
*& Author  : Academic Project 2024-25
*& Created : SE38 — paste this code and activate
*&---------------------------------------------------------------------*
*
*  HOW TO USE:
*  1. Open SE38, enter program name ZGEBI_VENDOR_STOCK_SO_RPT, click Create
*  2. Paste this entire code, Save and Activate (Ctrl+F3)
*  3. Open SE93, create transaction ZGEBI01 pointing to this report
*  4. Open SE11, create flat structure ZGEBI_ALV_STR with same fields as TY_OUTPUT
*  5. Run via ZGEBI01 or SE38 F8
*
*&---------------------------------------------------------------------*

REPORT ZGEBI_VENDOR_STOCK_SO_RPT
        LINE-SIZE 255
        MESSAGE-ID ZGE_MESSAGES.   "create via SE91 if needed, or remove this line

*----------------------------------------------------------------------*
* TYPE-POOLS
*----------------------------------------------------------------------*
TYPE-POOLS: SLIS.

*----------------------------------------------------------------------*
* TABLES  (for SELECT-OPTIONS field references)
*----------------------------------------------------------------------*
TABLES: LFA1,   "Vendor Master General
        EKKO,   "Purchasing Document Header
        EKPO,   "Purchasing Document Item
        MARD,   "Storage Location Stock
        VBAK,   "Sales Document Header
        VBAP.   "Sales Document Item

*----------------------------------------------------------------------*
* CUSTOM OUTPUT STRUCTURE
* Also create this in SE11 as structure ZGEBI_ALV_STR for reuse
*----------------------------------------------------------------------*
TYPES: BEGIN OF TY_OUTPUT,
  LIFNR  TYPE LFA1-LIFNR,      "Vendor Number
  NAME1  TYPE LFA1-NAME1,      "Vendor Name
  EBELN  TYPE EKKO-EBELN,      "Purchase Order Number
  BUKRS  TYPE EKKO-BUKRS,      "Company Code
  WERKS  TYPE EKPO-WERKS,      "Plant
  MATNR  TYPE EKPO-MATNR,      "Material Number
  TXZ01  TYPE EKPO-TXZ01,      "Material Description (short)
  MENGE  TYPE EKPO-MENGE,      "PO Order Quantity
  MEINS  TYPE EKPO-MEINS,      "Unit of Measure
  NETWR  TYPE EKPO-NETWR,      "Net Value of PO Item
  WAERS  TYPE EKKO-WAERS,      "Currency
  LABST  TYPE MARD-LABST,      "Unrestricted-use Stock
  VBELN  TYPE VBAK-VBELN,      "Sales Order Number
  POSNR  TYPE VBAP-POSNR,      "Sales Order Item
  KWMENG TYPE VBAP-KWMENG,     "Sales Order Quantity
  LFSTATUS TYPE C,             "X = stock covers SO demand
END OF TY_OUTPUT.

*----------------------------------------------------------------------*
* GLOBAL DATA
*----------------------------------------------------------------------*
DATA: IT_OUTPUT   TYPE STANDARD TABLE OF TY_OUTPUT WITH HEADER LINE,
      WA_OUTPUT   TYPE TY_OUTPUT,
      IT_FIELDCAT TYPE SLIS_T_FIELDCAT_ALV,
      WA_FIELDCAT TYPE SLIS_FIELDCAT_ALV,
      GS_LAYOUT   TYPE SLIS_LAYOUT_ALV,
      GS_VARIANT  TYPE DISVARIANT,
      GT_EVENTS   TYPE SLIS_T_EVENT,
      GS_EVENT    TYPE SLIS_ALV_EVENT,
      GV_TITLE    TYPE LVC_TITLE.

*----------------------------------------------------------------------*
* SELECTION SCREEN
*----------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF BLOCK B1 WITH FRAME TITLE TEXT-001.
  SELECT-OPTIONS: S_BUKRS FOR EKKO-BUKRS OBLIGATORY DEFAULT 'GE01',
                  S_WERKS FOR EKPO-WERKS            DEFAULT 'P001',
                  S_LIFNR FOR EKKO-LIFNR,
                  S_MATNR FOR EKPO-MATNR,
                  S_AEDAT FOR EKKO-AEDAT.            "PO creation date
SELECTION-SCREEN END OF BLOCK B1.

SELECTION-SCREEN BEGIN OF BLOCK B2 WITH FRAME TITLE TEXT-002.
  PARAMETERS: P_MAXROW TYPE I DEFAULT 1000,          "max rows to read
              P_LGORT  TYPE LGORT_D DEFAULT 'SL01'.  "storage location for stock check
SELECTION-SCREEN END OF BLOCK B2.

*----------------------------------------------------------------------*
* INITIALIZATION
*----------------------------------------------------------------------*
INITIALIZATION.
  TEXT-001 = 'Selection Criteria'.
  TEXT-002 = 'Additional Options'.
  GS_VARIANT-REPORT = SY-REPID.
  GV_TITLE = 'GlobalEdge: Vendor / Stock / Open Sales Orders'.

*----------------------------------------------------------------------*
* AT SELECTION-SCREEN  (basic input validation)
*----------------------------------------------------------------------*
AT SELECTION-SCREEN.
  IF P_MAXROW <= 0 OR P_MAXROW > 99999.
    MESSAGE 'Max rows must be between 1 and 99999.' TYPE 'E'.
  ENDIF.

*----------------------------------------------------------------------*
* START-OF-SELECTION
*----------------------------------------------------------------------*
START-OF-SELECTION.

  PERFORM CHECK_AUTHORIZATION.
  PERFORM FETCH_DATA.

  IF IT_OUTPUT IS INITIAL.
    MESSAGE 'No open PO records found for the selection.' TYPE 'I' DISPLAY LIKE 'W'.
    STOP.
  ENDIF.

  PERFORM CALCULATE_COVERAGE.
  PERFORM BUILD_FIELDCAT.
  PERFORM SET_LAYOUT.
  PERFORM SET_EVENTS.
  PERFORM DISPLAY_ALV.

*&---------------------------------------------------------------------*
*& FORM CHECK_AUTHORIZATION
*&---------------------------------------------------------------------*
FORM CHECK_AUTHORIZATION.
  LOOP AT S_BUKRS.
    AUTHORITY-CHECK OBJECT 'Z_GE_RPT'
      ID 'BUKRS' FIELD S_BUKRS-LOW
      ID 'ACTVT' FIELD '03'.
    IF SY-SUBRC <> 0.
      MESSAGE |No authorization for company code { S_BUKRS-LOW }| TYPE 'E'.
    ENDIF.
  ENDLOOP.
ENDFORM.

*&---------------------------------------------------------------------*
*& FORM FETCH_DATA
*& Reads Vendor + Open PO + Stock + linked Sales Order
*&---------------------------------------------------------------------*
FORM FETCH_DATA.

  DATA: LT_PO     TYPE STANDARD TABLE OF TY_OUTPUT,
        WA_PO     TYPE TY_OUTPUT,
        LV_LABST  TYPE MARD-LABST,
        LV_VBELN  TYPE VBAK-VBELN,
        LV_POSNR  TYPE VBAP-POSNR,
        LV_KWMENG TYPE VBAP-KWMENG,
        LV_COUNT  TYPE I.

  "-- Step 1: Vendor + Open Purchase Order lines -----------------------
  SELECT A~LIFNR A~NAME1
         B~EBELN B~BUKRS B~WAERS
         C~WERKS C~MATNR C~TXZ01 C~MENGE C~MEINS C~NETWR
    INTO CORRESPONDING FIELDS OF TABLE LT_PO
    FROM LFA1 AS A
    INNER JOIN EKKO AS B ON A~LIFNR = B~LIFNR
    INNER JOIN EKPO AS C ON B~EBELN = C~EBELN
    WHERE B~BUKRS IN S_BUKRS
      AND C~WERKS IN S_WERKS
      AND A~LIFNR IN S_LIFNR
      AND C~MATNR IN S_MATNR
      AND B~AEDAT IN S_AEDAT
      AND C~ELIKZ  = ' '          "Not fully delivered
      AND C~LOEKZ  = ' '          "Not deleted
      AND B~LOEKZ  = ' '          "Header not deleted
      AND B~STATU  <> 'I'         "Not blocked
    UP TO P_MAXROW ROWS.

  IF SY-SUBRC <> 0 OR LT_PO IS INITIAL.
    RETURN.
  ENDIF.

  "-- Step 2: Enrich each PO line with stock and sales order data ------
  LOOP AT LT_PO INTO WA_PO.
    LV_COUNT = LV_COUNT + 1.

    "Read unrestricted stock from MARD for this material/plant/sloc
    CLEAR LV_LABST.
    SELECT SINGLE LABST INTO LV_LABST
      FROM MARD
      WHERE MATNR = WA_PO-MATNR
        AND WERKS = WA_PO-WERKS
        AND LGORT = P_LGORT.
    WA_PO-LABST = LV_LABST.

    "Find the first open sales order for this material
    CLEAR: LV_VBELN, LV_POSNR, LV_KWMENG.
    SELECT A~VBELN B~POSNR B~KWMENG
      INTO (LV_VBELN, LV_POSNR, LV_KWMENG)
      FROM VBAK AS A
      INNER JOIN VBAP AS B ON A~VBELN = B~VBELN
      WHERE B~MATNR = WA_PO-MATNR
        AND A~AUART  = 'OR'       "Standard order
        AND A~BUKRS  IN S_BUKRS
        AND B~GBSTA  <> 'C'       "Not fully completed
      UP TO 1 ROWS.
    ENDSELECT.

    WA_PO-VBELN  = LV_VBELN.
    WA_PO-POSNR  = LV_POSNR.
    WA_PO-KWMENG = LV_KWMENG.

    APPEND WA_PO TO IT_OUTPUT.
    CLEAR WA_PO.
  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*& FORM CALCULATE_COVERAGE
*& Sets LFSTATUS flag: X if stock >= SO demand
*&---------------------------------------------------------------------*
FORM CALCULATE_COVERAGE.
  LOOP AT IT_OUTPUT INTO WA_OUTPUT.
    IF WA_OUTPUT-KWMENG > 0 AND WA_OUTPUT-LABST >= WA_OUTPUT-KWMENG.
      WA_OUTPUT-LFSTATUS = 'X'.
    ELSE.
      WA_OUTPUT-LFSTATUS = ' '.
    ENDIF.
    MODIFY IT_OUTPUT FROM WA_OUTPUT.
  ENDLOOP.
ENDFORM.

*&---------------------------------------------------------------------*
*& FORM BUILD_FIELDCAT
*& Builds ALV column definitions
*&---------------------------------------------------------------------*
FORM BUILD_FIELDCAT.

  "Auto-generate base fieldcat from our internal table
  CALL FUNCTION 'REUSE_ALV_FIELDCATALOG_MERGE'
    EXPORTING
      I_PROGRAM_NAME         = SY-REPID
      I_INTERNAL_TABNAME     = 'IT_OUTPUT'
      I_INCLNAME             = SY-REPID
    CHANGING
      CT_FIELDCAT            = IT_FIELDCAT
    EXCEPTIONS
      INCONSISTENT_INTERFACE = 1
      OTHERS                 = 2.

  "Manually customize each column
  LOOP AT IT_FIELDCAT INTO WA_FIELDCAT.
    CASE WA_FIELDCAT-FIELDNAME.
      WHEN 'LIFNR'.
        WA_FIELDCAT-SELTEXT_M = 'Vendor No.'.
        WA_FIELDCAT-KEY       = 'X'.
        WA_FIELDCAT-COL_POS   = 1.
      WHEN 'NAME1'.
        WA_FIELDCAT-SELTEXT_M = 'Vendor Name'.
        WA_FIELDCAT-COL_POS   = 2.
      WHEN 'EBELN'.
        WA_FIELDCAT-SELTEXT_M = 'PO Number'.
        WA_FIELDCAT-HOTSPOT   = 'X'.        "Click to open ME23N
        WA_FIELDCAT-COL_POS   = 3.
      WHEN 'BUKRS'.
        WA_FIELDCAT-SELTEXT_M = 'Co.Code'.
        WA_FIELDCAT-COL_POS   = 4.
      WHEN 'WERKS'.
        WA_FIELDCAT-SELTEXT_M = 'Plant'.
        WA_FIELDCAT-COL_POS   = 5.
      WHEN 'MATNR'.
        WA_FIELDCAT-SELTEXT_M = 'Material'.
        WA_FIELDCAT-COL_POS   = 6.
      WHEN 'TXZ01'.
        WA_FIELDCAT-SELTEXT_M = 'Description'.
        WA_FIELDCAT-COL_POS   = 7.
      WHEN 'MENGE'.
        WA_FIELDCAT-SELTEXT_M = 'PO Qty'.
        WA_FIELDCAT-DO_SUM    = 'X'.
        WA_FIELDCAT-COL_POS   = 8.
      WHEN 'MEINS'.
        WA_FIELDCAT-SELTEXT_M = 'UoM'.
        WA_FIELDCAT-COL_POS   = 9.
      WHEN 'NETWR'.
        WA_FIELDCAT-SELTEXT_M = 'Net Value'.
        WA_FIELDCAT-DO_SUM    = 'X'.
        WA_FIELDCAT-COL_POS   = 10.
      WHEN 'WAERS'.
        WA_FIELDCAT-SELTEXT_M = 'Currency'.
        WA_FIELDCAT-COL_POS   = 11.
      WHEN 'LABST'.
        WA_FIELDCAT-SELTEXT_M = 'Unr.Stock'.
        WA_FIELDCAT-DO_SUM    = 'X'.
        WA_FIELDCAT-COL_POS   = 12.
      WHEN 'VBELN'.
        WA_FIELDCAT-SELTEXT_M = 'Sales Order'.
        WA_FIELDCAT-COL_POS   = 13.
      WHEN 'POSNR'.
        WA_FIELDCAT-SELTEXT_M = 'SO Item'.
        WA_FIELDCAT-COL_POS   = 14.
      WHEN 'KWMENG'.
        WA_FIELDCAT-SELTEXT_M = 'SO Qty'.
        WA_FIELDCAT-DO_SUM    = 'X'.
        WA_FIELDCAT-COL_POS   = 15.
      WHEN 'LFSTATUS'.
        WA_FIELDCAT-SELTEXT_M = 'Stock OK?'.
        WA_FIELDCAT-COL_POS   = 16.
        WA_FIELDCAT-CHECKBOX  = 'X'.
    ENDCASE.
    MODIFY IT_FIELDCAT FROM WA_FIELDCAT.
  ENDLOOP.

  "Sort by column position
  SORT IT_FIELDCAT BY COL_POS.

ENDFORM.

*&---------------------------------------------------------------------*
*& FORM SET_LAYOUT
*&---------------------------------------------------------------------*
FORM SET_LAYOUT.
  GS_LAYOUT-ZEBRA             = 'X'.   "Alternating row colors
  GS_LAYOUT-COLWIDTH_OPTIMIZE = 'X'.   "Auto column width
  GS_LAYOUT-TOTALS_TEXT       = 'Grand Total'.
  GS_LAYOUT-DETAIL_POPUP      = 'X'.   "Row detail popup on click
  GS_LAYOUT-NO_ROWMARK        = ' '.
  GS_LAYOUT-INFO_FIELDNAME    = ' '.
ENDFORM.

*&---------------------------------------------------------------------*
*& FORM SET_EVENTS
*& Register TOP-OF-PAGE for report header
*&---------------------------------------------------------------------*
FORM SET_EVENTS.
  GS_EVENT-NAME    = SLIS_EV_TOP_OF_PAGE.
  GS_EVENT-FORM    = 'TOP_OF_PAGE'.
  APPEND GS_EVENT TO GT_EVENTS.
ENDFORM.

*&---------------------------------------------------------------------*
*& FORM DISPLAY_ALV
*&---------------------------------------------------------------------*
FORM DISPLAY_ALV.
  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      I_CALLBACK_PROGRAM      = SY-REPID
      I_CALLBACK_USER_COMMAND = 'USER_COMMAND'
      I_GRID_TITLE            = GV_TITLE
      IS_LAYOUT               = GS_LAYOUT
      IT_FIELDCAT             = IT_FIELDCAT
      IT_EVENTS               = GT_EVENTS
      IS_VARIANT              = GS_VARIANT
      I_SAVE                  = 'A'         "Allow save of variants
      I_DEFAULT               = 'X'
    TABLES
      T_OUTTAB                = IT_OUTPUT
    EXCEPTIONS
      PROGRAM_ERROR           = 1
      OTHERS                  = 2.

  IF SY-SUBRC <> 0.
    MESSAGE 'Error displaying ALV report. Check fieldcat.' TYPE 'E'.
  ENDIF.
ENDFORM.

*&---------------------------------------------------------------------*
*& FORM USER_COMMAND
*& Handles hotspot click on PO Number column -> opens ME23N
*&---------------------------------------------------------------------*
FORM USER_COMMAND USING R_UCOMM     TYPE SY-UCOMM
                        RS_SELFIELD TYPE SLIS_SELFIELD.

  CASE R_UCOMM.
    WHEN '&IC1'.   "Hotspot click
      READ TABLE IT_OUTPUT INTO WA_OUTPUT INDEX RS_SELFIELD-TABINDEX.
      IF SY-SUBRC = 0.
        CASE RS_SELFIELD-FIELDNAME.
          WHEN 'EBELN'.
            "Open PO in ME23N display mode
            SET PARAMETER ID 'BES' FIELD WA_OUTPUT-EBELN.
            CALL TRANSACTION 'ME23N' AND SKIP FIRST SCREEN.

          WHEN 'VBELN'.
            "Open Sales Order in VA03 display mode
            SET PARAMETER ID 'AUN' FIELD WA_OUTPUT-VBELN.
            CALL TRANSACTION 'VA03' AND SKIP FIRST SCREEN.
        ENDCASE.
      ENDIF.
  ENDCASE.

ENDFORM.

*&---------------------------------------------------------------------*
*& FORM TOP_OF_PAGE
*& Prints header above ALV grid
*&---------------------------------------------------------------------*
FORM TOP_OF_PAGE.
  DATA: LT_HEADER TYPE SLIS_T_LISTHEADER,
        WA_HEADER TYPE SLIS_LISTHEADER.

  "Line 1 — Title
  WA_HEADER-TYP  = 'H'.
  WA_HEADER-INFO = 'GlobalEdge Industries — Vendor / Stock / Sales Order Report'.
  APPEND WA_HEADER TO LT_HEADER. CLEAR WA_HEADER.

  "Line 2 — Run info
  WA_HEADER-TYP  = 'S'.
  WA_HEADER-KEY  = 'Run by: '.
  WA_HEADER-INFO = SY-UNAME.
  APPEND WA_HEADER TO LT_HEADER. CLEAR WA_HEADER.

  WA_HEADER-TYP  = 'S'.
  WA_HEADER-KEY  = 'Date: '.
  WRITE SY-DATUM TO WA_HEADER-INFO.
  APPEND WA_HEADER TO LT_HEADER. CLEAR WA_HEADER.

  WA_HEADER-TYP  = 'S'.
  WA_HEADER-KEY  = 'Records: '.
  WA_HEADER-INFO = lines( IT_OUTPUT ).
  APPEND WA_HEADER TO LT_HEADER. CLEAR WA_HEADER.

  CALL FUNCTION 'REUSE_ALV_COMMENTARY_WRITE'
    EXPORTING IT_LIST_COMMENTARY = LT_HEADER.

ENDFORM.
*&---------------------------------------------------------------------*
*& END OF REPORT ZGEBI_VENDOR_STOCK_SO_RPT
*&---------------------------------------------------------------------*
